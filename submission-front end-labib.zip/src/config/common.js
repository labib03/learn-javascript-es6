export const BASE_URL = 'https://api.themoviedb.org/3'
export const apiKey = '118de07197bd7b071b341f2ee835c67a'
export const TRENDING_IMAGE_URL = 'https://image.tmdb.org/t/p/w500'
export const RESULT_IMAGE_URL = 'https://image.tmdb.org/t/p/w200'

export const pathMovies = '/search/movie'
